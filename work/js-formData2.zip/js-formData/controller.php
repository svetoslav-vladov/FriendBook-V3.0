<?php 
	echo '<pre>';
	var_dump($_POST);
	var_dump($_FILES);
	echo '</pre>';
?>