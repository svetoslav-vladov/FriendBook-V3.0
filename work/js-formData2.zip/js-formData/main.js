// the form by id
var theForm = document.querySelector('#theForm');

if(theForm){
    theForm.addEventListener('submit', function (e){
		// prevent form from normal post sending 
        e.preventDefault();

        var requestXhr = new XMLHttpRequest();
		
		// form data object js
        var form = new FormData(theForm);
		
		// .onload <-- status 200 / readyState 4
        requestXhr.onload = function () {
            var result = this.responseText;
            
			document.querySelector('#returnData').innerHTML = '';
			document.querySelector('#returnData').innerHTML = result;
            
        };
		
        requestXhr.open('POST','./controller.php',true);
		
		// send form data, this will send all the form like normal post form
        requestXhr.send(form);

    });
}